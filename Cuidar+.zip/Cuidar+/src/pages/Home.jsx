// Home.jsx
import React from 'react';

function Home() {
  return (
    <main style={{ padding: '2rem' }}>
      <h2>Bem-vindo ao Cuidar+</h2>
      <p>Encontre cuidadores de idosos confiáveis, experientes e com empatia.</p>
      <p>Nosso compromisso é com o bem-estar de quem você ama.</p>
    </main>
  );
}

export default Home;
